-- Admin tasks table
CREATE TABLE IF NOT EXISTS admin_tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  type ENUM('social','video','survey','install') DEFAULT 'social',
  platform VARCHAR(50) DEFAULT '',
  url VARCHAR(500) NOT NULL,
  reward_xp INT DEFAULT 10,
  code_type ENUM('universal','individual') DEFAULT 'universal',
  verify_code VARCHAR(20) DEFAULT NULL,        -- used when code_type = 'universal'
  active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Individual codes pool (used when code_type = 'individual')
CREATE TABLE IF NOT EXISTS task_codes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  task_id INT NOT NULL,
  code VARCHAR(20) NOT NULL UNIQUE,
  used_by INT DEFAULT NULL,                    -- user_id who redeemed it
  used_at TIMESTAMP NULL DEFAULT NULL,
  FOREIGN KEY (task_id) REFERENCES admin_tasks(id) ON DELETE CASCADE
);

-- Task completions log
CREATE TABLE IF NOT EXISTS task_completions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  task_id INT NOT NULL,
  code_used VARCHAR(20),
  completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_completion (user_id, task_id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (task_id) REFERENCES admin_tasks(id)
);

-- Migration: add new columns if upgrading from old schema
ALTER TABLE admin_tasks
  ADD COLUMN IF NOT EXISTS code_type ENUM('universal','individual') DEFAULT 'universal' AFTER reward_xp;
